var Person = function(config) {
    this.name = config.name;
    this.age = config.age;
    this.occupation = congif.occupation;

}

Person.prototype.work = function(){
 return this.name + " is working. "

}
